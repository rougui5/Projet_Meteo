package com.example.projet;

// Annotation pour indiquer le nom de la propriété JSON lors de la sérialisation et la désérialisation

public @interface JsonProperty {
}
