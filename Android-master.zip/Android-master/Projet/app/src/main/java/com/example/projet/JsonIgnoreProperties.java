package com.example.projet;

// Annotation pour ignorer les propriétés JSON inattendues lors de la désérialisation

public @interface JsonIgnoreProperties {
}
